<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meat name="viewport" content="width=device-width , initial-scale=1.0"> 
    <title>Search data</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        ul.navbar {
            list-style-type: none;
            margin: 0;
            padding: 0;
        
            overflow: hidden;
            display: flex;
            justify-content: flex-end;
            position:fixed;
            top:2%;
            height:46px;
            background:white;
            width:100%;
            margin-top:-1%;
        }

        li.navitem {
            
        }

        li.navitem a {
            display: block;
            color: black;
            text-align: center;
            padding: 10px 12px;
            text-decoration: none;
        }

        li.navitem a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<ul class="navbar">
        <li class="navitem"><a href="me.html">Home   </a></li>
        <li class="navitem"><a href="dashboard.html">Portal  </a></li>
        <li class="navitem"><a href="contausv2.html">Help?  </a></li>
    </ul>
<div class="container my-5" >
    <center>
    <form  method="post">
        <input type="text" placeholder="serach data" name="search">
        <button class="btn btn-dark btn-sm" name="submit">search</button>
    </form> 
</center>
    <div class="container my-5">
        <table class="table">
    <?php
   if (isset($_POST['submit'])) {
    $search = $_POST['search'];
    $sql = "SELECT * FROM registration WHERE idno like '%$search%' or firstname like '%$search%' or lastname like '%$search%' or skills like '%$search%' ";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        echo '<thead>
            <tr>
                <th>ID NO</th>
                <th>NAME</th>
                <th>E-MAIL</th>
                <th>SKILLS</th>
            </tr>
        </thead>';

        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>
             <td><a href="searchData.php?data='. $row['idno'] .'"> '. $row['idno'] .'</td>
               <td> ' . $row['firstname'] . ' ' . $row['lastname'] .'</td>
                <td>' . $row['email'] . '</td>
                <td>' . $row['skills'] . '</td>
            </tr>';
        }
    } else {
        echo " ";
    }
}
    ?>

        </table>   
</div>
</body>
</html>
