<?php
$con = mysqli_connect('localhost', 'root', '', 'project');
if (!$con) {
    die("Error: " . mysqli_error($con));
}
?>
