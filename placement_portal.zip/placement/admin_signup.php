<?php
session_start();
include("admin_connect.php");
include("admin_func.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    //something was posted
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if (!empty($user_name) && !empty($password) && !is_numeric($user_name)) {
        //save to database
        $user_id = random_num(20);
        $query = "insert into admin (user_id,user_name,password) values ('$user_id','$user_name','$password')";
        mysqli_query($con, $query);
        //previously here login.php
        header("Location:admin_reg.html");
        die;
    } else {
        echo "Please enter some valid information!";   }
}
?>

