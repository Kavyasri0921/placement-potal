<!doctype html>
<html>
<head>
<title>register page</title>
<script>
function validation(){
	var firstname=document.getElementById("fname").value;
	var lastname=document.getElementById("lname").value;
	var email=document.getElementById("mail").value;
	var tel=document.getElementById("phnno").value;
	var pregx=/^[0-9]{10}$/;
	else if(firstname=="")
	{
		alert("please enter your firstname");
		return false;
	}
	else if(lastname=="")
	{
		alert("please enter your lastname");
		return false;
	}
	else if(email=="")
	{
		alert("please enter email id")
		return false;
	}
	else if(pw=="")
	{
		alert("please enter password");
		return false;
	}
	else if(tel=="")
	{
		alert("please enter phone number")
	}
	else if(!pregx.test(tel))
	{
		alert("phone number should contain 10 digits");
		return false;
	}
	else
	{
		return true;
	}
}
</script>
<style>
	body
	{	
		background-image:url("https://res.cloudinary.com/duwn22rv1/image/upload/v1717680766/blue-toned-collection-paper-sheets-with-copy-space_ooxsb9.jpg");
		background-size:cover;
		font-family:'Poppins', sans-serif;
	}
	div
	{	margin:auto;
		display:grid;
		place-items:center;
		width:50%;
		padding:15px;
		font-size:20px;
		color:white;
		background:linear-gradient(#9FACBC,#C6D3E4);
		opacity:1;
		border-radius:20px;
	}
	label
	{
		width:200px;
		display:inline-block;
		
	}
	input
	{
		width:300px;
		height:30px;
		background-color:white;
		border-color:#E7EEF7;
		border-style:solid;
		font-size:13px;
	}
	input :hover{
		border-color:#D0DAE7;}
	select
	{
		width:305px;
		height:35px;
	}
	button
	{
		width:500px;
		height:50px;
		background-color:linear-gradient(#636363,#a2ab58);
		color:black;
		border-radius:10px;
		font-weight:500;
		font-size:15px;
	}
	button:hover
	{
		background-color:#F5F7FA ;
	
	}
</style>
</head>
<body>
<div>
	<form id="form" onsubmit='return validation()' action="admin_reg_connect.php" method="post">
	<h1 style="color:white; font-family:'Poppins', sans-serif;"> <center>REGISTRATION  FORM</center></h1>
	

	<label>First Name:</label>
	<input type="text" id="fname" placeholder="enter your firstname" name="fname"><br><br>
	<label>Last Name:</label>
	<input type="text" id="lname" placeholder="enter your lastname" name="lname"><br><br>
	<label>E-Mail ID:</label>
	<input type="email" id="mail" placeholder="enter your clg mail id" name="mail"><br><br>
	
	<label>Phone Number:</label>
	<input type="tel" id="phnno" placeholder="enter your phonenumber" minlength="10" name="phnno"><br><br>
	
	<label>Company Name:</label>
	<input type="text" name="company_name" placeholder="enter currently studying year"><br><br>
	
	<label>Stipend Offered:</label>
	<input type="text" placeholder="working place..." name="stipend"><br><br>
	
	<label>Skills required:</label>
	<textarea rows="5" cols="41" placeholder="mention your skills" type="text" name="skills"></textarea><br><br>
	
	<label>Job Description:</label>
	<textarea rows="5" cols="41" placeholder="description" type="text" name="description"></textarea><br><br>
	
	<a href="dashboard.html"><center><button type="submit">Submit</button></center></a>
	</form>
</div>
</body>
</html>
