<?php
	$firstname=$_POST['fname'];
	$lastname=$_POST['lname'];
	$email=$_POST['mail'];
	$phonenumber=$_POST['phnno'];
	$company_name=$_POST['company_name'];
	$stipend=$_POST['stipend'];
	$skills=$_POST['skills'];
	$desc=$_POST['description'];
	$servername = "localhost";
	$username = "root";
	$password2 = "";
	$dbname = "login_sample_db";
	$conn = mysqli_connect($servername, $username, $password2, $dbname);
	if($conn){
		#echo "connected successfully";
		header("Location:flip_admin.html");
	}
	$sql = "INSERT INTO 'admin_reg' (`firstname`, `lastname`, `email`, `phonenumber`,`company_name`,`stipend`,`skills`,`description`) VALUES ('$firstname','$lastname','$email',$phonenumber,'$company_name','$stipend','$skills','$desc')";
	
	$quert=mysqli_query($conn, $sql);
	if($quert){
		echo "records inserted successfully";
		header("Location:flip_admin.html");
	}
?>
