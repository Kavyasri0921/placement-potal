<!--LOGIN PAGE-->
<?php
session_start();
include("connection.php");
include("functions.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    //something was posted
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];

    if (!empty($user_name) && !empty($password) && !is_numeric($user_name)) {
        //read  from database

        $query = "select * from users where user_name='$user_name' limit 1";
        $result = mysqli_query($con, $query);
        if ($result) {
            if ($result && mysqli_num_rows($result) > 0) {
                $user_data = mysqli_fetch_assoc($result);
                if ($user_data['password'] === $password) {
                    $_SESSION['user_id'] = $user_data['user_id'];
                    header("Location:dashboard.html");
                    die;
                }
            }
        
        }//echo "wrong user name or password!"
        echo '<div style="color: #9EEDCE; font-weight: bold; text-align: center; position: absolute; top: 80; left: 50%; transform: translateX(-50%);">!!Wrong user name or password!</div>';
        
    } else {
        //echo "wrong username or pasword";
        echo '<div style="color: #9EEDCE;background-color:white;padding:10px;border-radius:10px; font-weight: bold; text-align: center; position: absolute; top: 80; left: 50%; transform: translateX(-50%);">!!Wrong user name or password!</div>';
    }
}
?>


