<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meat name="viewport" content="width=device-width , initial-scale=1.0"> 
    <title>Search data</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
    	body{
    		 background-image:url("https://res.cloudinary.com/duwn22rv1/image/upload/v1717681109/v915-wit-005_gicahz.jpg");
    		 width:100vw;
    		 height:100vh;
    		 background-size:cover;
    		 }
        ul.navbar {
            list-style-type: none;
            margin: 0;
            padding: 0;
        
            overflow: hidden;
            display: flex;
            justify-content: flex-end;
            position:fixed;
            top:2%;
            height:65px;
            background:#C9F1F6  ;
            width:100%;
            margin-top:-1%;
        }

        li.navitem {
        }

        li.navitem a {
            display: block;
            color: black;
            text-align: center;
            padding: 10px 12px;
            text-decoration: none;
            font-size:17px;
        }

        li.navitem a:hover {
            text-decoration: underline;
        }
        input{
        	width:400px;
        	height:40px;
        	border-radius:7px;
        	padding:5px;
        	border-color:black;
        	margin-top:15px;
        }
        input:hover {
            border-color:black;
        }
        button{
        border-radius:10px;
        margin-bottom:2px;
        margin-left:3px;
        width:80px;
    </style>
</head>
<body>
<ul class="navbar">
<a href="dashboard.html"><img src="https://res.cloudinary.com/duwn22rv1/image/upload/v1701276697/back_ey43eq.png" width="50" height="50" style="margin-top:10px;margin-right:1000px;"></a>
        <li class="navitem"><a href="Home.html">Home   </a></li>
        <li class="navitem"><a href="dashboard.html">Portal  </a></li>
        <li class="navitem"><a href="text.html">Help?  </a></li>
    </ul>
<div class="container my-5" >
    <center>
    <form  method="post">
        <input type="text" placeholder="serach data" name="search" style="margin-top:50px;">
        <button class="btn btn-dark btn-sm" style="margin-top:0px;" name="submit">search</button>
    </form> 
</center>
    <div class="container my-5">
        <table class="table">
    <?php
   if (isset($_POST['submit'])) {
    $search = $_POST['search'];
    $sql = "SELECT * FROM registration WHERE idno like '%$search%' or firstname like '%$search%' or lastname like '%$search%' or skills like '%$search%' ";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        echo '<thead>
            <tr>
                <th>ID NO</th>
                <th>NAME</th>
                <th>E-MAIL</th>
                <th>SKILLS</th>
            </tr>
        </thead>';

        while ($row = mysqli_fetch_assoc($result)) {
            echo '<tr>
             <td><a href="searchData.php?data='. $row['IDNO'] .'"> '. $row['IDNO'] .'</td>
               <td> ' . $row['FIRSTNAME'] . ' ' . $row['LASTNAME'] .'</td>
                <td>' . $row['EMAIL'] . '</td>
                <td>' . $row['SKILLS'] . '</td>
            </tr>';
        }
    } else {
        echo " ";
    }
}
    ?>

        </table>   
</div>
</body>
</html>
